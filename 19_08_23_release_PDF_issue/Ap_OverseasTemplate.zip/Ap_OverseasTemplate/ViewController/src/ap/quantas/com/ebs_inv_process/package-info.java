@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/pcbpel/adapter/db/sp/QFEQ_AP_INV_IMG_PROCESS", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.oracle.xmlns.pcbpel.adapter.db.sp.qfeq_ap_inv_img_process;
