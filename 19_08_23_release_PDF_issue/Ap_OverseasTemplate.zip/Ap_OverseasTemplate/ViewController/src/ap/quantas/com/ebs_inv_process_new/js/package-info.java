@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/pcbpel/adapter/db/sp/JSEQ_INV_IMG_PROCESS", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package ap.quantas.com.ebs_inv_process_new.js;
