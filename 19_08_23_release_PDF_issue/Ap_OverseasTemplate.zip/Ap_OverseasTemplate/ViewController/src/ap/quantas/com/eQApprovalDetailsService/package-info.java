@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/pcbpel/adapter/db/sp/approverDetails", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package ap.qantas.com.eQApprovalDetailsService;
