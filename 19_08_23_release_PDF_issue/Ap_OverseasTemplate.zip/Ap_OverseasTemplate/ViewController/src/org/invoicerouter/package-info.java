@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.InvoiceRouter.org", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.invoicerouter;
